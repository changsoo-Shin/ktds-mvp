"""
Azure App Service용 시작 스크립트
"""

import os
import sys
import subprocess

# Python 경로 설정
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Streamlit 앱 실행
if __name__ == "__main__":
    # 환경 변수 설정
    os.environ['STREAMLIT_SERVER_PORT'] = os.environ.get('PORT', '8501')
    os.environ['STREAMLIT_SERVER_ADDRESS'] = '0.0.0.0'
    os.environ['STREAMLIT_SERVER_HEADLESS'] = 'true'
    os.environ['STREAMLIT_BROWSER_GATHER_USAGE_STATS'] = 'false'
    
    # Streamlit 실행
    subprocess.run([
        sys.executable, '-m', 'streamlit', 'run', 
        os.path.join(os.path.dirname(__file__), 'src', 'app.py'),
        '--server.port', os.environ.get('PORT', '8501'),
        '--server.address', '0.0.0.0',
        '--server.headless', 'true'
    ])
